function gp_js_querystring(ji) {
    hu = window.location.search.substring(1);
    gy = hu.split( "&" );
    for (i=0;i<gy.length;i++) {
        ft = gy[i].split( "=" );
        if (ft[0] == ji) {

            return ft[1];
        }
    }
}

(
	function(){
	
		// Get the URL to this script file (as JavaScript is loaded in order)
		// (http://stackoverflow.com/questions/2255689/how-to-get-the-file-path-of-the-currenctly-executing-javascript-code)
		
		var scripts = document.getElementsByTagName( "script"),
		src = scripts[scripts.length-1].src;
		
		if ( scripts.length ) {
		
			for ( i in scripts ) {

				var scriptSrc = '';
				
				if ( typeof scripts[i].src != 'undefined' ) { scriptSrc = scripts[i].src; } // End IF Statement
	
				var txt = scriptSrc.search( 'shortcode-generator' );
				
				if ( txt != -1 ) {
				
					src = scripts[i].src;
				
				} // End IF Statement
			
			} // End FOR Loop
		
		} // End IF Statement

		var framework_url = src.split( '/js/' );
		
		var icon_url = framework_url[0] + '/images/shortcode-icon.png';
		
		tinymce.PluginManager.add('gpthemes_shortcodes_button', function(editor, url) {
			
			editor.addCommand( 'gpOpenDialog', function( a, c ){
				
				// Grab the selected text from the content editor.
				selectedText = '';
			
				if ( editor.selection.getContent().length > 0 ) {
			
					selectedText = editor.selection.getContent();
					
				} // End IF Statement
				
				gpSelectedShortcodeType = c.identifier;
				gpSelectedShortcodeTitle = c.title;
				
				
				jQuery.get(url+"/dialog.php",function(b){
					
					jQuery( '#gp-options').addClass( 'shortcode-' + gpSelectedShortcodeType );
					jQuery( '#gp-preview').addClass( 'shortcode-' + gpSelectedShortcodeType );
					
					// Skip the popup on certain shortcodes.
					
					switch ( gpSelectedShortcodeType ) {
				
						// Highlight
						
						case 'highlight':
					
						var a = '[highlight]'+selectedText+'[/highlight]';
						
						tinyMCE.activeEditor.execCommand( "mceInsertContent", false, a);
					
						break;
						
						// Dropcap
						
						case 'dropcap':
					
						var a = '[dropcap]'+selectedText+'[/dropcap]';
						
						tinyMCE.activeEditor.execCommand( "mceInsertContent", false, a);
					
						break;
				
						default:
						
						jQuery( "#gp-dialog").remove();
						jQuery( "body").append(b);
						jQuery( "#gp-dialog").hide();
						var f=jQuery(window).width();
						b=jQuery(window).height();
						f=720<f?720:f;
						f-=80;
						b-=84;
					
						tb_show( "Insert "+ gpSelectedShortcodeTitle +" Shortcode", "#TB_inline?width="+f+"&height="+b+"&inlineId=gp-dialog" );jQuery( "#gp-options h3:first").text( "Customize the "+c.title+" Shortcode" );
						break;
					
					} // End SWITCH Statement
				
				});
			});

			var layout_menu_items = [
		        { onclick: function(e){ addImmediate('Column Full', '[column_full][/column_full] ') }, text: 'Column Full' },
		        { onclick: function(e){ addImmediate('Column Wrap', '[column_wrap][/column_wrap] ') }, text: 'Column Wrap' },
		        { onclick: function(e){ addImmediate('Column Half', '[column_half][/column_half] ') }, text: 'Column Half' },
		        { onclick: function(e){ addImmediate('Column Two Third', '[column_two_third][/column_two_third] ') }, text: 'Column Two Third' },
		        { onclick: function(e){ addImmediate('Column One Third', '[column_one_third][/column_one_third] ') }, text: 'Column One Third' },
		        { onclick: function(e){ addImmediate('Column Three Fourth', '[column_three_fourth][/column_three_fourth] ') }, text: 'Column Three Fourth' },
		        { onclick: function(e){ addImmediate('Column One Fourth', '[column_one_fourth][/column_one_fourth] ') }, text: 'Column One Fourth' },
		        { onclick: function(e){ addImmediate('Column Five Sixth', '[column_five_sixth][/column_five_sixth] ') }, text: 'Column Five Sixth' },
		        { onclick: function(e){ addImmediate('Column One Sixth', '[column_one_sixth][/column_one_sixth] ') }, text: 'Column One Sixth' },
		        { onclick: function(e){ addImmediate('Column Eleven Twelveth', '[column_eleven_twelveth][/column_eleven_twelveth] ') }, text: 'Column Eleven Twelveth' },
		        { onclick: function(e){ addImmediate('Column One Twelveth', '[column_one_twelveth][/column_one_twelveth] ') }, text: 'Column One Twelveth' },
		    ];
			
			var video_menu_items = [
		        { onclick: function(e){ addWithDialog('Youtube', 'youtube') }, text: 'Youtube' },
		        { onclick: function(e){ addWithDialog('Vimeo', 'vimeo') }, text: 'Vimeo' },
		    ];
			
			var menu_items = [
		        { onclick: function(e){ addWithDialog('Alert', 'alert') }, text: 'Alert' },
		        { onclick: function(e){ addWithDialog('Badge', 'badge') }, text: 'Badge' },
		        { onclick: function(e){ addWithDialog('Block Message', 'block-message') }, text: 'Block Message' },
		        { onclick: function(e){ addWithDialog('Blockquote', 'blockquote') }, text: 'Blockquote' },
		        { onclick: function(e){ addWithDialog('Button', 'button') }, text: 'Button' },
		        { onclick: function(e){}, text: 'Column Layout', menu: layout_menu_items },
				{ onclick: function(e){ addImmediate('Code', '[code] [/code]') }, text: 'Code' },
		        { onclick: function(e){ addImmediate('Divider', '[divider]') }, text: 'Divider' },
		        { onclick: function(e){ addWithDialog('Hero', 'hero') }, text: 'Hero' },
		        { onclick: function(e){ addWithDialog('Icon', 'icon') }, text: 'Icon' },
		        { onclick: function(e){ addWithDialog('Label', 'label') }, text: 'Label' },
		        { onclick: function(e){ addWithDialog('Table', 'table') }, text: 'Table' },
		        { onclick: function(e){ addWithDialog('Tabset', 'tab') }, text: 'Tabset' },
		        { onclick: function(e){ addWithDialog('Tagline', 'tagline') }, text: 'Tagline' },
		        { onclick: function(e){ addWithDialog('Tooltip', 'tooltip') }, text: 'Tooltip' },
		        { onclick: function(e){}, text: 'Video', menu: video_menu_items },
		    ];
		
		    editor.addButton('gpthemes_shortcodes_button', {
				title: 'Insert PressApps Shortcode',
	            type: 'menubutton',
	            icon: 'gpthemes_shortcodes_icon',
				menu: menu_items
			});

			function addImmediate( label, shortcode ) {
				tinyMCE.activeEditor.execCommand( "mceInsertContent", false, shortcode );
			}
			
			function addWithDialog( label, shortcode ) {
				tinyMCE.activeEditor.execCommand( "gpOpenDialog", false, {
					title: label,
					identifier: shortcode
				});
			}
		});
	}
)();