gpShortcodeMeta={
	attributes:[
		{
			label:"ID",
			id:"id",
			help:"Enter video id e.g. 9UprxM_aBWk",
			isRequired:true
		},
		{
			label:"Width",
			id:"width",
			help:"Enter video width e.g. 500",
			isRequired:true
		},
		{
			label:"Height",
			id:"height",
			help:"Enter video height e.g. 281",
			isRequired:true
		}
		],
		shortcode:"youtube"
};