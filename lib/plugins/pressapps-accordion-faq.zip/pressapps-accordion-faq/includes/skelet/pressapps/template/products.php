<?php 
/**
 * PressApps Product Template page
 * @since 1.0.0
 */
?>

<header class="pa-header">
	<h1><?php _e( 'Products By PressApps', SK_TEXTDOMAIN ); ?></h1>
</header>

<div id="pa-products"></div>